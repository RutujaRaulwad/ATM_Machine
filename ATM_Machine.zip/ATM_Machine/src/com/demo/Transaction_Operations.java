package com.demo;

import java.util.HashMap;
import java.util.Map;

public class Transaction_Operations implements Atm_Functions {
	
	Atm_Interface atm=new Atm_Interface();
	
	Map<Double,String>ministmt=new HashMap<>();
			
		public void viewBalance() 
		{
	    	System.out.println("Available balnce is :"+atm.getBalance());	
		}

		@Override
		public void withdrwal(double withdrwal)
		{
			// TODO Auto-generated method stub
			if(withdrwal%500==0) 
			{
		    if(withdrwal<=atm.getBalance())
		    {
		    ministmt.put(withdrwal,"  Amount withdrawn");	
		    
		    System.out.println("Collect the Cash  "+withdrwal);
		    
		    atm.setBalance(atm.getBalance()-withdrwal);
		    
		    viewBalance();
		    }
		    else 
		    {
		    	System.out.println("Insufficient Balnce !!");
		    }
		}
			else
			{
				System.out.println("Please enter amount in multiple of 500");
			}
				
			}

		@Override
		public void  deposite(double deposite)
		{
			ministmt.put(deposite,"  Amount deposited");
			
			System.out.println(deposite+"Deposite successfully !!");
			
			atm.setBalance(atm.getBalance()+deposite);
			viewBalance();
		
		}

		@Override
		public void viewMiniStatement()
		{
			for(Map.Entry<Double,String>m:ministmt.entrySet())
			{
				System.out.println(m.getKey()+""+m.getValue());
			}
			
		}

	}


