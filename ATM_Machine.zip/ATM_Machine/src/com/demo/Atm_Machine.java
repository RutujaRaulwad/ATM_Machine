package com.demo;

public class Atm_Machine

{
	private double balance ;
	private double deposite;
	private double withdrwal;

}
