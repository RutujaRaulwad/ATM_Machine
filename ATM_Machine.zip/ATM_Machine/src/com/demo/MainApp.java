package com.demo;

import java.util.Scanner;

public class MainApp {

	public static void main(String[] args) {
    
		Atm_Functions	obj =new Transaction_Operations();
	    int atmnumber=123;
	    int atmpin=11;
	    
	    Scanner in=new Scanner(System.in);
	    System.out.println(" ******** welcome to ATM machine ******** ");
	    
	    System.out.println("");
	    System.out.print("Enter atm number :");
	    int atmNumber=in.nextInt();
	    
	    System.out.print("Enter a pin :");
	    int pin=in.nextInt();
	    
	    if((atmnumber==atmNumber)&&(atmpin==pin))
	    {
	    	System.out.println(" Successfully loged in..........");
	    	System.out.println("");
	    	
	    	while(true)
	    	{
	    		System.out.println("");
	    		System.out.println("------------------------------------------------------------------");
	    		System.out.println("1.view available balance\n2.Withdwral Amount \n3.Deposite Amount\n4.Transactions history\n5.Exit");
	    	    System.out.println("Enter your choice : ");
	    	    System.out.println();
	    	    int ch=in.nextInt();
	    	    
	    	    if(ch==1)
	    	    {
	    	       obj.viewBalance();
	    	    }
	    	    
	    	    else if(ch==2) 
	    	    {
	    	    System.out.println("");
	    	    System.out.println("Enter amount to withdrawl :");
	    	    double withdrwal=in.nextDouble();
	    	    obj.withdrwal(withdrwal);
	    	    	
	    	    	
	    	    }
	            else if(ch==3)
	            {
	            	System.out.println("");
	    	    	System.out.println("Enter Ammount for deposite :");
	    	    	double deposite=in.nextDouble();//5000
	    	    	obj.deposite(deposite);
	    	    }
	    	    
	            else if(ch==4)
	            {
	            	obj.viewMiniStatement();
	    	    	
	    	    }
	    	    
	            else if(ch==5) 
	            {
	    	    	
	    	    System.out.println("Collect your atm card \n !! Thank you for using atm machine !!");	
	    	    System.exit(0);
	            }
	            else
	            {
	            	System.out.println("please enter correct choice");
	            }
	    	}
		}

		else{

	    	System.out.println("incorrect atm pin");
	        System.exit(0);
	        }

	    


	}

}
